import { LightningElement } from 'lwc';

export default class User extends LightningElement {}